#include <xc.h>
#include <stdint.h>
#include <ctype.h>
#include <stdio.h>
#include "UART1.h"
#include "BitWhacker.h"
#include "config.h"

void ProcesaOrden(char orden[])
{
    int i = 0;

    // 1) Pasar todo a mayúsculas
    while(orden[i] != '\0'){
        orden[i] = toupper(orden[i]);
        i++;
    }

    // 2) Comando Normal(N),  Con Azucar (Yes) o Sin Azucar (No)
    if((orden[0] == 'N' || orden[0] == 'C' || orden[0] == 'L') && (orden[2] == 'Y'|| orden[2] == 'N')){
        
        if(orden[1] != ','){ //|| orden[3] != '\n'
            putsUART("Error\n");
            return;
        }
        
        asm("di");
        tipo_cafe = orden[0];
        azucar = orden[2];
        pedido_correcto = 1;
        asm("ei");

        putsUART("Pedido recibido\n");
        return;
    }

    // 3) Instrucción desconocida
    putsUART("Instruccion desconocida\n");
}
