#ifndef TIMERS_H
#define TIMERS_H

#ifdef __cplusplus
extern "C" {
#endif
    
    
void initTimers(void);
void initTimer1(void);
void initTimer2(void);
void initTimer3(void);
void reiniciarFlagsT3(void);
int getFlagsT3(void);

#ifdef __cplusplus
}
#endif

#endif /* TIMERS_H */