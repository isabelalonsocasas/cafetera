
#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h> // Para sin, cos y tan
#include "Pic32Ini.h"
#include "TftDriver/TftDriver.h"
#include "Pantalla.h"

#define PIN_PULSADOR  5

void iniciarPantalla (void){
    extern uint8_t SmallFont[];
    inicializarTFT(PORTRAIT);
    setFont(SmallFont);
}


void pantallaInicio (void){
    clrScr();
    fillScr(VGA_WHITE);

    setColor(VGA_FUCHSIA);
    fillRect(0, 0, 127, 25);

    fillRect(0, 154, 127, 159);   // abajo
    fillRect(0, 0, 5, 159);       // izquierda
    fillRect(122, 0, 127, 159);   // derecha


    setColor(VGA_WHITE);
    setBackColor(VGA_FUCHSIA);
    print("LA CAFETERA", CENTER, 8, 0);


    setColor(VGA_FUCHSIA);
    setBackColor(VGA_WHITE);
    print("Cafetera lista", CENTER, 70, 0);
    print("Elija su cafe", CENTER, 90, 0);  
}

void pantallaPreparando (void){
    clrScr();
    fillScr(VGA_WHITE);

    setColor(VGA_FUCHSIA);
    fillRect(0, 0, 127, 25);

    fillRect(0, 154, 127, 159);   // abajo
    fillRect(0, 0, 5, 159);       // izquierda
    fillRect(122, 0, 127, 159);   // derecha


    setColor(VGA_WHITE);
    setBackColor(VGA_FUCHSIA);
    print("LA CAFETERA", CENTER, 8, 0);


    setColor(VGA_FUCHSIA);
    setBackColor(VGA_WHITE);
    print("Su cafe esta", CENTER, 60, 0);
    print("siendo", CENTER, 80, 0);  
    print("preparado", CENTER, 100, 0); 
}

void pantallaSirviendo (void){
    clrScr();
    fillScr(VGA_WHITE);

    setColor(VGA_FUCHSIA);
    fillRect(0, 0, 127, 25);

    fillRect(0, 154, 127, 159);   // abajo
    fillRect(0, 0, 5, 159);       // izquierda
    fillRect(122, 0, 127, 159);   // derecha


    setColor(VGA_WHITE);
    setBackColor(VGA_FUCHSIA);
    print("LA CAFETERA", CENTER, 8, 0);


    setColor(VGA_FUCHSIA);
    setBackColor(VGA_WHITE);
    print("Su cafe se", CENTER, 50, 0);
    print("esta sirviendo", CENTER, 70, 0);  
    print("no retire", CENTER, 90, 0); 
    print("el vaso", CENTER, 110,0);  
}

void pantallaColocaVaso(void) {
    clrScr();
    fillScr(VGA_FUCHSIA);

    setColor(VGA_WHITE);
    fillRect(0, 0, 127, 25);

    fillRect(0, 154, 127, 159);   // abajo
    fillRect(0, 0, 5, 159);       // izquierda
    fillRect(122, 0, 127, 159);   // derecha


    setColor(VGA_WHITE);
    setBackColor(VGA_FUCHSIA);
    print("LA CAFETERA", CENTER, 8, 0);
    
    print("PAUSA", CENTER, 50, 0);
    print("Coloque un", CENTER, 70, 0);  
    print("vaso para", CENTER, 90, 0); 
    print("servirle", CENTER, 110,0);
}

void pantallaCafeListo (void ){
    clrScr();
    fillScr(VGA_WHITE);

    setColor(VGA_FUCHSIA);
    fillRect(0, 0, 127, 25);

    fillRect(0, 154, 127, 159);   // abajo
    fillRect(0, 0, 5, 159);       // izquierda
    fillRect(122, 0, 127, 159);   // derecha


    setColor(VGA_WHITE);
    setBackColor(VGA_FUCHSIA);
    print("LA CAFETERA", CENTER, 8, 0);


    setColor(VGA_FUCHSIA);
    setBackColor(VGA_WHITE);
    print("Cafe listo", CENTER, 70, 0);
    print("Retire su cafe", CENTER, 90, 0);  
}

void pause(void)
{
	while(PORTB & (1<<PIN_PULSADOR) ); // Espera hasta que se pulse SW2 (RB2)
	while(!(PORTB & (1<<PIN_PULSADOR))); // Espera hasta que se suelte.
}
