
#ifndef _EXAMPLE_FILE_NAME_H    
#define _EXAMPLE_FILE_NAME_H

#ifdef __cplusplus
extern "C" {
#endif

void iniciarPantalla (void);
void pantallaInicio (void);
void pantallaPreparando (void);
void pantallaSirviendo (void);
void pantallaColocaVaso(void);
void pantallaCafeListo (void);
void pause(void);
    

#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
