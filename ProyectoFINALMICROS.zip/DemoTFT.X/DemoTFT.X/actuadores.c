#include <xc.h>
#include <stdint.h>
#include "actuadores.h"
#include "config.h"


void bombaON(void){
    LATACLR = 1 << PIN_RELE_BOMBA; 
}
void bombaOFF(void){ 
    LATASET = 1 << PIN_RELE_BOMBA;
}

void valvulaON(void){
    LATCCLR = 1 << PIN_RELE_ELECTROVALVULA;
}

void valvulaOFF(void){
    LATCSET = 1 << PIN_RELE_ELECTROVALVULA; 
}

int motorON(void){
    LATCCLR = 1 << PIN_RELE_MOTOR;
    
}

int motorOFF(void){
    LATCSET = 1 << PIN_RELE_MOTOR;
    
}

int calefactorON(void){
    LATCCLR = 1 << PIN_RELE_CALEFACTOR;
}

int calefactorOFF(void){
   LATCSET = 1 << PIN_RELE_CALEFACTOR;
}

int apagarTodo(void){
    bombaOFF();
    valvulaOFF();
    motorOFF();
    calefactorOFF();
}