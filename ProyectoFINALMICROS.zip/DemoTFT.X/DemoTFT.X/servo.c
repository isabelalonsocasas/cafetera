#include <xc.h>
#include "servo.h"
#include "timers.h"

void initServos(void){
    
    int t_alto = 1250;  // Tiempo en alto inicial 0.5 ms, -90� 

    
   

    // CONFIGURACI�N OUTPUT COMPARE (OC2)
    OC2CON = 0;  // Primero apagamos OC1
    OC2R = 1350;  
    OC2RS = 1350;
    OC2CON = 0x8006;  // Modo PWM sin fallos (OCM = 110)

    OC2CON |= (1 << 15);  // ON = 1, activar OC
    
    // CONFIGURACI�N OUTPUT COMPARE (OC3)
    OC3CON = 0;  // Primero apagamos OC1
    OC3R = t_alto;  
    OC3RS = t_alto;
    OC3CON = 0x8006;  // Modo PWM sin fallos (OCM = 110)

    OC3CON |= (1 << 15);  // ON = 1, activar OC
    
    initTimer2();
}


void abrirServoCafe(void){
    int t_alto = 2000; // A modificar para ver cuanto caf� queremos que pase
    OC2RS = t_alto;
}
void cerrarServoCafe(void){
    int t_alto = 1350;
    OC2RS = t_alto;
}

void abrirServoAzucar(void){
    int t_alto = 1900; // A modificar para ver cuanto az�car queremos que pase
    OC3RS = t_alto;
}
void cerrarServoAzucar(void){
    int t_alto = 1250; // A modificar para ver cuanto caf� queremos que pase
    OC3RS = t_alto;
}