
#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <stdint.h>
#include "UART1.h"
#include "BitWhacker.h"
#include "actuadores.h"
#include "sensores.h"
#include "Pic32Ini.h"
#include "config.h"
#include "servo.h"
#include "timers.h"
#include "Pantalla.h"

int main(void) {
        
        
    
    while(1){
        abrirServoCafe();
        
    }

    return;
}

