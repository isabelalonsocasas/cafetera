#include <xc.h>
#include <stdint.h>
#include "UART1.h"
#include "BitWhacker.h"
#include "actuadores.h"
#include "sensores.h"
#include "Pic32Ini.h"
#include "config.h"
#include "servo.h"
#include "timers.h"
#include "Pantalla.h"

static int pulsador_ant, pulsador_act;

char tipo_cafe = 'N';
char azucar = 'Y';
int pedido_correcto = 0;

int main(void)
{ 
    int cafe_echado = 0;
    int azucar_echado = 0;
    int agua_echada = 0;
    int mezcla_preparada = 0;
    int fin_cafe = 0;
    int sensor_presencia = 1;
    int necesidad_azucar = 1;
    int temperatura_agua = 0;
    int pulsador_ant, pulsador_act;
    
    enum {Inicio, Espera_Datos, Comprobaciones, Echar_Agua, Echar_Cafe, 
    Echar_Azucar, Terminar_Remover, Servir_Cafe, Pausa, Fin_Cafe, Error} estado;
    
    estado = Inicio;
    
    
    pulsador_ant = (PORTB >> PIN_PULSADOR) & 1;
    
    initPines();
    initTimers();
    //InicializarUART1(9600);
    //initSensorTemperatura();
    // REMAPEO DE OC2 AL RA9 Y DE OC3 A RB14
    SYSKEY = 0xAA996655;  
    SYSKEY = 0x556699AA;
    RPA9R = 5;
    RPB14R = 5;
    SYSKEY = 0x1CA11CA1;
    iniciarPantalla ();
    
    
     // Habilitar interrupciones
    INTCONbits.MVEC = 1;
    asm("ei");
    
    //pantallaInicio ();
    
    while(1)
    {
        // Presionas pulsador
        pulsador_act = (PORTB >> PIN_PULSADOR) & 1;
        
        if ((pulsador_ant != pulsador_act) && (pulsador_act == 0)){
            tipo_cafe = 'N'; 
            azucar = 'Y'; 
            pedido_correcto = 1; 
        }
        
        pulsador_ant = pulsador_act;
        
        switch(estado){
            case Inicio:
                pantallaInicio ();
                pedido_correcto = 0;
                cafe_echado = 0;
                azucar_echado = 0;
                agua_echada = 0;
                mezcla_preparada = 0;
                fin_cafe = 0;
                sensor_presencia = 1;
                necesidad_azucar = 1;
                temperatura_agua = 0;
                //initPines();
                //initTimers();
                InicializarUART1(9600);
                initSensorTemperatura();
                apagarTodo();
                estado = Espera_Datos;
                break;
                
            case Espera_Datos:
                if (pedido_correcto == 1){
                    reiniciarFlagsT3(); 
                    initTimer3();
                    initServos();
                    pantallaPreparando ();
                    estado = Comprobaciones;
                }
                break;
                
            case Comprobaciones:
                if (temperatura_agua == 1){
                    reiniciarFlagsT3();
                    estado = Echar_Agua;
                }
                break;
            
            case Echar_Agua: 
                if (agua_echada == 1){
                    reiniciarFlagsT3();
                    estado = Echar_Cafe;
                }
                break;
                
            case Echar_Cafe:
                if((cafe_echado == 1) && (azucar == 'Y')){ //MODIFICAR
                    reiniciarFlagsT3();
                    estado = Echar_Azucar;
                }
                
                if((cafe_echado == 1) && (azucar == 'N')){ //MODIFICAR
                    reiniciarFlagsT3();
                    estado = Terminar_Remover;
                }
                break;
                
            case Echar_Azucar:
                if (azucar_echado == 1){
                    reiniciarFlagsT3();
                    estado = Terminar_Remover;
                }
                
                break;
                
            case Terminar_Remover:
                if (mezcla_preparada == 1){
                    reiniciarFlagsT3();
                    sensor_presencia = leerSensorIR();
                    pantallaSirviendo ();
                    estado = Servir_Cafe;
                }
                break;
                
            case Servir_Cafe:
                if (sensor_presencia == 0){
                    pantallaColocaVaso();
                    estado = Pausa;
                }
                
                if (fin_cafe == 1){
                    pantallaCafeListo ();
                    estado = Fin_Cafe;
                }
                break;
                
            case Pausa:
                if (sensor_presencia == 1){
                    reiniciarFlagsT3();
                    pantallaSirviendo ();
                    estado = Servir_Cafe;
                }
                break;
                
            case Fin_Cafe:
                if (sensor_presencia == 0){
                    estado = Inicio;
                }
        }
        
        

        
        if (estado == Espera_Datos){
            recibirOrden();    
            LATCSET = 1 << PIN_LED_LISTO;
            LATCCLR = 1 << PIN_LED_APAGADO;
        }
        
        if (estado == Comprobaciones){
            //pantallaInicio ();
            desactivarReceptor();
            calefactorON();
            // temperatura_agua = leerADC
            int temp = devolverTemperaturaActual();
            if (leerADCTemperatura() == 1){
                temperatura_agua = 1;
            }
            LATCSET = 1 << PIN_LED_APAGADO;
            LATCCLR = 1 << PIN_LED_PREPARACION;
        }
        
        if (estado == Echar_Agua){
            calefactorOFF();
            valvulaON();
            
            LATCSET = 1 << PIN_LED_PREPARACION;
            LATCCLR = 1 << PIN_LED_LISTO; 
            
            if (tipo_cafe == 'C'){
                if (getFlagsT3() == 8){
                    valvulaOFF();
                    agua_echada = 1;
                }
            }
            
            if (tipo_cafe == 'N'){
                if (getFlagsT3() == 10){
                    valvulaOFF();
                    agua_echada = 1;
                }
            }
            
            if (tipo_cafe == 'L'){
                if (getFlagsT3() == 12){
                    valvulaOFF();
                    agua_echada = 1;;
                }
            }
        }
        
        if (estado == Echar_Cafe){
            motorON();
            abrirServoCafe();
            
            // CAMBIAR TODO 
            if (tipo_cafe == 'C'){
                if (getFlagsT3() == 4){
                    cerrarServoCafe();
                    cafe_echado = 1;
                }
            }
            
            if (tipo_cafe == 'N'){
                if (getFlagsT3() == 6){
                    cerrarServoCafe();
                    cafe_echado = 1;
                }
            }
            
            if (tipo_cafe == 'L'){
                if (getFlagsT3() == 8){
                    cerrarServoCafe();
                    cafe_echado = 1;
                }
            }
            
        }
        
        if (estado == Echar_Azucar){
            abrirServoAzucar();
            
            if (getFlagsT3() == 5){
                azucar_echado = 1;
                cerrarServoAzucar();
            }
        }
        
        if (estado == Terminar_Remover){
            if (getFlagsT3() == 90){
                mezcla_preparada = 1;
                motorOFF();
            }
        }
        
        if (estado == Servir_Cafe){
            bombaON();
            sensor_presencia = leerSensorIR();
            
            // CAMBIAR TODO 
            if (tipo_cafe == 'C'){
                if (getFlagsT3() == 60){
                    bombaOFF();
                    fin_cafe = 1;
                }
            }
            
            if (tipo_cafe == 'N'){
                if (getFlagsT3() == 180){
                    bombaOFF();
                    fin_cafe = 1;
                }
            }
            
            if (tipo_cafe == 'L'){
                if (getFlagsT3() == 260){
                    bombaOFF();
                    fin_cafe = 1;
                }
            }
        }
        
        if (estado == Pausa){
            bombaOFF();
            sensor_presencia = leerSensorIR();
        }
        
        if (estado == Fin_Cafe){
            sensor_presencia = leerSensorIR();
        }
       
    }
}

