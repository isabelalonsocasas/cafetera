#include <xc.h>
#include "sensores.h"
#include "config.h"

static int sensorPresencia = 1; // 1 si hay vaso, 0 si no hay vaso
static volatile int sensorTemperatura = 0; //1 cuando llegue  a la temperatura correcta
static volatile int temperatura_actual = 0 ; 

int temperatura_15 = 625; 
int temperatura_40 = 389; 
int temperatura_35 = 440; 
int temperatura_30 = 504;

void initSensorTemperatura(void){
    
    AD1CON1 = 0; 
    AD1CON2 = 0; //1 CONVERSION
    AD1CON3 = 0X200; // SAMC=2 
    AD1CHS = 0; 
    AD1CON1bits.SSRC = 7; 
    AD1CON1bits.ASAM = 1; 
    IFS0bits.AD1IF = 0; 
    IEC0bits.AD1IE = 1; 
    IPC5bits.AD1IP = 3; 
    IPC5bits.AD1IS = 0; 
    AD1CON1bits.ON = 1; 
    
}

int leerSensorIR(void){
    
    sensorPresencia = ~((PORTB >> PIN_SENSOR_PRESENCIA) & 0x1);
    asm("di");
    int hayVaso = sensorPresencia & 0x0001;
    asm("ei");
    return hayVaso;
}

__attribute__((vector(23), interrupt(IPL3SOFT), nomips16)) void interrupcionTemperatura(void){
    
    IFS0bits.AD1IF = 0; 
    temperatura_actual = ADC1BUF0; 
    
    if ((int)temperatura_actual < (int)temperatura_35) {
        asm("di");
        sensorTemperatura = 1;
        asm("ei");
    } else{
        sensorTemperatura = 0;
    }
}

int leerADCTemperatura(void){
    asm("di");
    int temperatura_correcta = sensorTemperatura; 
    asm("ei");
    return temperatura_correcta; 
}

int devolverTemperaturaActual (void){
    asm("di");
    int temp_actual = temperatura_actual;
    asm("ei");
    return temp_actual; 
}