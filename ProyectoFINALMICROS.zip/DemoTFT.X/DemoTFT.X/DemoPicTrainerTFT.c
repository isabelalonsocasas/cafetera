#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h> // Para sin, cos y tan
#include "Pic32Ini.h"
#include "TftDriver/TftDriver.h"
#include "Pantalla.h"

#define PIN_PULSADOR  5

void pause(void);

int main()
{
    // Configuración del pulsador y los LEDs
  ANSELC &= ~0xF;                // Pines de los LEDs como digitales
  ANSELB &= (1<<PIN_PULSADOR);   // Pin del pulsador también como digital
  
  LATA = 0;   // En el arranque dejamos todas las salidas no usadas a 0
  LATB = 0; 
  LATC = 0xF; // Apago los LEDs de la placa
  
  // Pines como salidas
  TRISA = 0;
  TRISB = 1 << PIN_PULSADOR;
  TRISC = 0;

  iniciarPantalla();
  
  while(1){
    pause();
    iniciarPantalla ();
    pause();
    pantallaInicio ();
    pause();
    pantallaPreparando ();
    pause();
    pantallaSirviendo ();
    pause();
    pantallaColocaVaso();
    pause();
    pantallaCafeListo ();
    pause();
  }
}

