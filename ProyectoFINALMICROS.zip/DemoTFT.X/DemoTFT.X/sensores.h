#ifndef SENSORES_H 
#define SENSORES_H

#ifdef __cplusplus
extern "C" {
#endif
    
void initSensorTemperatura (void);

int leerSensorIR(void);

int leerADCTemperatura(void);
int devolverTemperaturaActual(void);

#ifdef __cplusplus
}
#endif

#endif /* SENSORES_H */